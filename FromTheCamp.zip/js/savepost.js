function saveImage(){
var saveImg = document.getElementById("save_img");
saveImg.style.backgroundColor = "blue";

}